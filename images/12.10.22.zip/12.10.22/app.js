const showButton = document.getElementById("button");
const add = document.getElementById("add");
const para1 = document.getElementById("para1");
const para2 = document.getElementById("para2");
const arr = ["Ania", "Robert", "Kasia", "Patryk"];

function show() {
    if (para1.textContent === "") {
        for (let i = 0; i < arr.length; i++) {
            para1.innerHTML += `${i + 1}. ${arr[i]} <br>`
        }
    } else {
        para1.textContent = "";
    }
}

button.addEventListener("click", show);

add.addEventListener("click", () => {
    let amount = prompt("Ile chcesz dodać osób?");
    for (let i = 0; i < amount; i++) {
        person = prompt("Podaj imie osoby");
        arr.push(person);
        para2.innerHTML += `Dodano ${person} <br>`;
    }

    show();
})